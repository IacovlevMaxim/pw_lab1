package data.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

/**
 * Class in charge of getting the connection to the database
 */
public class DBConnection {

	protected String url;
	protected String user;
	protected String password;
	
	/**
	 * Tries to connect to the database
	 * @return The connection to the database
	 */
	public DBConnection(String configFile) {
		Properties properties = new Properties();
		try {
			FileInputStream input = new FileInputStream(configFile);
			properties.load(input);
			
			this.user = properties.getProperty("user");
			this.password = properties.getProperty("passwd");
			this.url = properties.getProperty("url");
			
		} catch (IOException ex) {
            ex.printStackTrace();
        }
	}
	
	/**
	 * Tries to connect to the database
	 * @return The connection to the database
	 */
	public Connection getConnection(){

		Connection connection=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = (Connection) DriverManager.getConnection(url, user, password);
		} 
		catch (SQLException e) {
			System.err.println("Connection to MySQL has failed!");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found.");
			e.printStackTrace();
		}
		return connection;
	}

}