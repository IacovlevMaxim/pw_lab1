package data.DAO;

import java.sql.*;
import java.util.ArrayList;

import business.CourtDTO;
import business.enums.CourtSize;
import data.common.QueriesLoader;
import data.common.DBConnection;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToReserveException;

/**
 * Data access object for the courts
 */
public class CourtDAO {
	
	QueriesLoader loader;
	private Connection connection;
	
	/**
	 * Empty constructor
	 */
	public CourtDAO(String configFile) {
		
		loader = new QueriesLoader();
		DBConnection dbc = new DBConnection(configFile);
		connection = dbc.getConnection();
	}
	
	/**
     * Destroys the connection to the database
     */
    public void destroy() {
        try {
            if(this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch(Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
    }
	
		
		/**
		 * Gets a court from the database by the name
		 * @param name Name of the court
		 * @return The court if it was found, null if it wasn't
		 */
		public CourtDTO requestCourtByName(String name)
		{
			CourtDTO court = new CourtDTO();
			
			try
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("CourtNameFilter"));
				stmt.setString(1, name);
				ResultSet rs = stmt.executeQuery();
				
				if(!rs.next()) {return null;}
				
				int id = rs.getInt("id");
				boolean status = rs.getBoolean("status");
				boolean type = rs.getBoolean("type");
				int maxNum = rs.getInt("max_players");
                CourtSize size = CourtSize.valueOf(rs.getString("size"));
				
				court = new CourtDTO(id, name, status, type, size, maxNum);
				
				if(stmt != null) {stmt.close();}
				
				
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
			return court;
			
		}
		
		/**
		 * Gets the ID of a specific court
		 * @param name The name of the court
		 * @return The ID of the court
		 */
		public Integer getCourtId(String name)
		{
			Integer id=null;
			try
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("CourtNameFilter"));
				stmt.setString(1, name);
				ResultSet rs = stmt.executeQuery();
				
				if(!rs.next()) {return null;}
				
				id = rs.getInt("id");
				
				if(stmt != null) {stmt.close();}
				
				
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			return id;
			
		}
		/**
		 * Gets all courts from the database
		 * @return The list with all courts
		 */
		public ArrayList<CourtDTO> requestAllCourts()
		{
			ArrayList<CourtDTO> courts = new ArrayList<CourtDTO>();
			
			try 
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("CourtsAllFilter"));
				ResultSet rs = stmt.executeQuery();
				
	            while(rs.next())
	            {
					int id = rs.getInt("id");
	                String name = rs.getString("name");
	                boolean status = rs.getBoolean("status");
	                boolean type = rs.getBoolean("type");
	                CourtSize size = CourtSize.valueOf(rs.getString("size"));
	                int maxNum = rs.getInt("max_players");

	                courts.add(new CourtDTO(id, name, status, type, size, maxNum));
	            }
	            
				if (stmt != null) {stmt.close();}
				
			
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
			return courts;
			
		}
		
		/**
		 * Adds a new court to the database
		 * @param court Information of the court to add
		 */
		public void addNewCourt(CourtDTO court)
		{
			try 
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("InsertNewCourt"));
				
				stmt.setString(1, court.getName()); 
	            stmt.setInt(2, court.getStatus() ? 1 : 0);
	            stmt.setInt(3, court.getType() ? 1 : 0);
	            stmt.setString(4, court.getSize().name());
				stmt.setInt(5, court.getMaxNum());
				
				stmt.executeUpdate();
				
				if (stmt != null) {stmt.close();}
				
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
		}
		
		/**
		 * Deletes a court from the database
		 * @param name Name of the court to delete
		 * @throws CourtNotFoundException
		 */
		public void deleteCourt(String name) throws CourtNotFoundException 
		{
			
			try 
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("DeleteCourt"));
				stmt.setString(1, name);
				int rs = stmt.executeUpdate();

				if(rs==0) 
				{
					
	            	throw new CourtNotFoundException("That name does not belong to any court\n");
				
				}
				
				if (stmt != null) {stmt.close();}
				
				
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
		
		}
		
		/**
		 * Modifies a court from the database
		 * @param name Name of the court to modify
		 * @param court New information of the court
		 * @return true if the modification was successful, false otherwise
		 */
		public boolean modifyCourt(String name, CourtDTO court) 
		{
			
			try 
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ModifyCourt"));

				stmt.setString(1, court.getName()); 
				stmt.setBoolean(2, court.getStatus());
	            stmt.setBoolean(3, court.getType());
				stmt.setInt(4, court.getMaxNum());
	            
				int rs=stmt.executeUpdate();

				if(rs==0) {return false;}
				
				if(stmt != null) {stmt.close();}
				
				
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
			return true;
		}
		
		/**
		 * Reserves a court for a reservation
		 * @param name Name of the court to reserve
		 * @throws CourtNotFoundException
		 * @throws ImpossibleToReserveException
		 */
		public void reserveCourtByName(String name) throws CourtNotFoundException, ImpossibleToReserveException {
			try {
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("CourtNameFilter"));
				
				stmt.setString(1, name);
				
	            ResultSet rs = stmt.executeQuery();
				
	            if(!rs.next()) {
	            	throw new CourtNotFoundException("That ID does not belong to any court. Unable to reserve court.\n");
	            }

                boolean status = rs.getBoolean("status");
	            
	            if(!status)
	            {
	            	throw new ImpossibleToReserveException("The court is alreay reserved. Unable to reserve court.\n");
	            }
	            else
	            {
	            	stmt = connection.prepareStatement(loader.getProperty("ReserveCourt"));
	    			stmt.setString(1, name);
	                stmt.executeUpdate();
	            }
	            
				if (stmt != null){ 
					stmt.close(); 
				}
			
			}catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
		}
		
		/**
		 * Sets a court as available
		 * @param name Name of the court to be unreserved
		 * @throws CourtNotFoundException
		 * @throws ImpossibleToReserveException
		 */
		public void unreserveCourtByName(String name) throws CourtNotFoundException {
			try {
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("UnreserveCourtName"));
	    		stmt.setString(1, name);
	            Integer rs = stmt.executeUpdate();
	            
	            if(rs==0)
	            {
	            	throw new CourtNotFoundException("That ID does not belong to any court. Unable to reserve court.\n");
	            }
	            
				if (stmt != null){ 
					stmt.close(); 
				}
			} catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
		}
		
		/**
		 * Sets a court as available
		 * @param id ID of the court to be unreserved
		 * @throws CourtNotFoundException
		 * @throws ImpossibleToReserveException
		 */
		public void unreserveCourtById(Integer id) throws CourtNotFoundException {
			try {
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("UnreserveCourtId"));
	    		stmt.setInt(1, id);
	            Integer rs = stmt.executeUpdate();
	            
	            if(rs==0)
	            {
	            	throw new CourtNotFoundException("That ID does not belong to any court. Unable to reserve court.\n");
	            }
	            
				if (stmt != null){ 
					stmt.close(); 
				}
			
			}catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
		}
		
		/**
		 * Gets a list of courts fitted to a type and a date
		 * @param courtType Type of court (indoors or outdoors)
		 * @param date 
		 * @return
		 */
		public ArrayList<CourtDTO> requestAvailableCourtsByTypeAndDate(boolean courtType, Date date)
		{
		    ArrayList<CourtDTO> courts = new ArrayList<CourtDTO>();
		    
		    try 
		    {
		        
		        PreparedStatement stmt = connection.prepareStatement(loader.getProperty("CourtsAvailableByTypeAndDateFilter"));
		        stmt.setBoolean(1, courtType);  // Set the type of the court (boolean)
		        stmt.setString(2, date.toString());         // Set the reservation date
		        
		        ResultSet rs = stmt.executeQuery();
		        
		        while(rs.next())
		        {
		            int id = rs.getInt("id");
		            String name = rs.getString("name");
		            boolean status = rs.getBoolean("status");
		            boolean type = rs.getBoolean("type");
		            CourtSize size = CourtSize.valueOf(rs.getString("size"));
		            int maxNum = rs.getInt("max_players");
		
		            courts.add(new CourtDTO(id, name, status, type, size, maxNum));
		        }
		        
		        if (stmt != null) {stmt.close();}
		    
		    }
		    catch (Exception e)
		    {
		        System.err.println(e);
		        e.printStackTrace();
		    }
		    
		    return courts;
		}
		
		/**
		 * Gets all fitting court from the database
		 * @param maxNum Number of players to fit
		 * @param size Size of the desired courts
		 * @return The list of courts that fit that criteria
		 */
		public ArrayList<CourtDTO> requestFittingCourts(int maxNum, CourtSize size)
		{
			ArrayList<CourtDTO> courts = new ArrayList<CourtDTO>();
			try 
			{
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("FittingCourtsFilter"));
	            stmt.setInt(1, maxNum);
	            stmt.setString(2, size.name());
				
				ResultSet rs = stmt.executeQuery();
				
	            while(rs.next())
	            {
					int id = rs.getInt("id");
	                String name = rs.getString("name");
	                boolean status = rs.getBoolean("status");
	                boolean type = rs.getBoolean("type");
	                int num = rs.getInt("max_players");

	                courts.add(new CourtDTO(id, name, status, type, size, num));
	            }
	            
				if (stmt != null) {stmt.close();}
				
			
			}
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
			return courts;
			
		}
		
		/**
		 * Gets all fitting and available courts from the database
		 * @param maxNum Number of players to fit
		 * @param size Size of the desired courts
		 * @return The list of courts that fit that criteria
		 */
		public ArrayList<CourtDTO> requestFittingAvailableCourts(int maxNum, CourtSize size, boolean type)
		{
			ArrayList<CourtDTO> courts = new ArrayList<CourtDTO>();
			try 
			{
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("FittingAvailableCourtsFilter"));
	            stmt.setInt(1, maxNum);
	            stmt.setString(2, size.name());
	            stmt.setInt(3, type ? 1 : 0);
				
				ResultSet rs = stmt.executeQuery();
				
	            while(rs.next())
	            {
					int id = rs.getInt("id");
	                String name = rs.getString("name");
	                boolean status = rs.getBoolean("status");
	                int num = rs.getInt("max_players");

	                courts.add(new CourtDTO(id, name, status, type, size, num));
	            }
	            
				if (stmt != null) {stmt.close();}
				
			
			}
			
			catch (Exception e)
			{
				System.err.println(e);
				e.printStackTrace();
			}
			
			return courts;
			
		}
			
		/**
		 * Gets a list with all the unavailable courts in the database
		 * @return The list with the unavailable courts
		 */
		public ArrayList<CourtDTO> requestUnavailableCourts()
		{
			ArrayList<CourtDTO> courts = new ArrayList<CourtDTO>();
			
			try 
			{
				
				PreparedStatement stmt = connection.prepareStatement(loader.getProperty("CourtsUnavailableFilter"));
	            stmt.setInt(1, 0);
				
				ResultSet rs = stmt.executeQuery();
				
	            while(rs.next())
	            {
					int id = rs.getInt("id");
	                String name = rs.getString("name");
	                boolean type = rs.getBoolean("type");
	                CourtSize size = CourtSize.valueOf(rs.getString("size"));
	                int maxNum = rs.getInt("max_players");

	                courts.add(new CourtDTO(id, name, false, type, size, maxNum));
	            }
	            
				if (stmt != null) {stmt.close();}
				
			
			}
			
			catch (SQLException e) {
				System.err.println(e);
				e.printStackTrace();
			}
			
			return courts;
			
		}
	}

