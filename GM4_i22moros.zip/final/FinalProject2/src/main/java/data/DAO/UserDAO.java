package data.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import business.UserDTO;
import data.common.DBConnection;
import data.common.QueriesLoader;

/**
 * DAO for the login information of the users
 */
public class UserDAO {

	QueriesLoader loader;
	private Connection connection;
	
	/**
	 * Empty constructor
	 */
	public UserDAO(String configFile){
		loader = new QueriesLoader();
		DBConnection dbc = new DBConnection(configFile);
		connection = dbc.getConnection();
	}
	
	/**
     * Destroys the connection to the database
     */
    public void destroy() {
        try {
            if(this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch(Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
    }
	
	/**
	 * Add a new user to the database
	 * @param user User to add
	 */
	public void addNewPlayer(UserDTO user){
		try {
			
			PreparedStatement stmt = connection.prepareStatement(loader.getProperty("InsertNewUser"));
			
			stmt.setString(1, user.getEmail()); 
			stmt.setString(2, user.getPassword());
            stmt.setInt(3, user.getType() ? 1 : 0);
			
			stmt.executeUpdate();
			
			if (stmt != null){ 
				stmt.close(); 
			}
		
		}catch (Exception e){
			System.err.println(e);
			e.printStackTrace();
		
		}
	}
	
	
	/**
	 * Gets an user using the email, from the database
	 * @param email Email of the user
	 * @return The user information
	 */
	public UserDTO requestUserByEmail(String email){
		UserDTO user = new UserDTO();
		try {
			
			PreparedStatement stmt = connection.prepareStatement(loader.getProperty("UserEmailFilter"));
			stmt.setString(1, email); // Set the ? in the queries file (for the first ?, replace with email)
            ResultSet rs = stmt.executeQuery();
			
            if(!rs.next()) {
            	return null;
            }
            
            String password = rs.getString("password");
            Boolean type = rs.getBoolean("type");
            user = new UserDTO(email, password, type);
            
			if (stmt != null){ 
				stmt.close(); 
			}
		
		}catch (Exception e){
			System.err.println(e);
			e.printStackTrace();
		}
		return user;
	}
	
	/**
	 * Modifies a user's information
	 * @param email Email of the user to modify
	 * @param ps Password of the user
	 * @return true if the operation was successful, false if the user was not found
	 */
	public boolean modifyUser(String email, String ps) {
		try {
			
			PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ModifyUser"));

			stmt.setString(2, email);
			stmt.setString(1, ps);
			
			int rs=stmt.executeUpdate();

			if(rs==0) {
            	return false;
			}
			
			if (stmt != null){ 
				stmt.close(); 
			}
		}catch (Exception e){
			System.err.println(e);
			e.printStackTrace();
		
		}
		return true;
	}
	
	/**
	 * Returns all users in the database
	 * @return The list with all the users in the database
	 */
	public ArrayList<UserDTO> requestAllUsers(){
		ArrayList<UserDTO> users = new ArrayList<UserDTO>();
		try {
			
			PreparedStatement stmt = connection.prepareStatement(loader.getProperty("UsersAllFilter"));
			
            ResultSet rs = stmt.executeQuery();
			
            while(rs.next())
            {
            	String password = rs.getString("password");
                String email = rs.getString("email");
                Boolean type = rs.getBoolean("type");

            	users.add(new UserDTO(email, password, type));
            }
            
			if (stmt != null){ 
				stmt.close(); 
			}
		
		}catch (Exception e){
			System.err.println(e);
			e.printStackTrace();
		}
		return users;
	}
}
