package business.enums;
/**
 * MaterialType (BALL, BASKET, CONE)
 */
public enum MaterialType {
    BALL,
    BASKET,
    CONE
}