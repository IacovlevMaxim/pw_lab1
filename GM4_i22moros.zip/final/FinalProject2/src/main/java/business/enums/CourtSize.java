package business.enums;
/**
 * Size of a Court (MINIBASKET, ADULTS, THREE_VS_THREE)
 */
public enum CourtSize {
	MINIBASKET,
	ADULTS, 
	THREE_VS_THREE
}