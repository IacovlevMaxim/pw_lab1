package business.exceptions;

public class ReservationNotFoundException extends Exception{
	
	/**
	 * Empty constructor
	 */
	public ReservationNotFoundException() {}
	/**
	 * Sends a message
	 * @param error The message to send
	 */
	public ReservationNotFoundException(String err)
	{
		
		super(err);
		
	}
}
