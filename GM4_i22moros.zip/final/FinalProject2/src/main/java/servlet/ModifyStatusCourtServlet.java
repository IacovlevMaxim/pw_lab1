package servlet;


import java.io.IOException;

import business.CourtManager;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToReserveException;
import display.CustomerBean;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ModifyStatusCourtServlet")
public class ModifyStatusCourtServlet extends HttpServlet{

	/** Serial ID */
	private static final long serialVersionUID = 4852333670670107286L;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		CustomerBean customerBean = (CustomerBean) session.getAttribute("customerBean");
		if (customerBean == null || customerBean.getEmail().equals("")) {
			response.sendRedirect(request.getContextPath() + "/mvc/index.jsp");
		}

		String name = request.getParameter("name");
		Boolean status = Boolean.valueOf(request.getParameter("status"));
		
		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		
		CourtManager cManager = new CourtManager(configFile);
		Boolean success = true;
		Boolean found=true;
		
		try {
			cManager.changeStatusCourt(name, status);
		}catch (ImpossibleToReserveException e) {
			// TODO Auto-generated catch block
			success=false;
		} catch (CourtNotFoundException e) {
			// TODO Auto-generated catch block
			found=false;
		} catch (Exception e) {
			cManager.closeManager();
		}

		cManager.closeManager();
		
		response.sendRedirect(request.getContextPath() + "/mvc/view/admin/ModifyStatusCourtView.jsp?success=" + success + "&found=" + found);
	}

}