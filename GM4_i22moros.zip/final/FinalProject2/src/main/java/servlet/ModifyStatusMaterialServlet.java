package servlet;


import java.io.IOException;

import business.CourtManager;
import business.enums.MaterialStatus;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToReserveException;
import business.exceptions.MaterialNotFoundException;
import display.CustomerBean;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ModifyStatusMaterialServlet")
public class ModifyStatusMaterialServlet extends HttpServlet{

	/** Serial ID */
	private static final long serialVersionUID = 4852333670670107286L;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		CustomerBean customerBean = (CustomerBean) session.getAttribute("customerBean");
		if (customerBean == null || customerBean.getEmail().equals("")) {
			response.sendRedirect(request.getContextPath() + "/mvc/index.jsp");
		}

		Integer id = Integer.valueOf(request.getParameter("id"));
		MaterialStatus status = MaterialStatus.valueOf(request.getParameter("status"));
		
		String name = request.getParameter("name");

		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		
		CourtManager cManager = new CourtManager(configFile);
		Boolean success = true;
		Boolean mFound=true;
		Boolean cFound=true;
		
		try {
			cManager.changeStatusMaterial(id, status, name);
		} catch (CourtNotFoundException e) {
			cFound=false;
		} catch (ImpossibleToReserveException e) {
			success=false;
		} catch (MaterialNotFoundException e) {
			mFound=false;
		} catch (Exception e) {
			cManager.closeManager();
		}

		cManager.closeManager();
		
		response.sendRedirect(request.getContextPath() + "/mvc/view/admin/ModifyStatusMaterialView.jsp?success=" + success + "&mfound=" + mFound + "&cfound=" + cFound);
	}

}