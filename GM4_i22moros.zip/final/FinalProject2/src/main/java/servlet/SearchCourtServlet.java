package servlet;

import data.DAO.CourtDAO;
import business.CourtDTO;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

@WebServlet("/SearchCourtServlet")
public class SearchCourtServlet extends HttpServlet
{
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		String courtType = request.getParameter("courtType");
		String searchDate = request.getParameter("searchDate");
		Integer maxNum = Integer.parseInt(request.getParameter("numParticipants"));

		if(courtType == null || searchDate == null || courtType.isEmpty() || searchDate.isEmpty())
		{
			
			request.setAttribute("message", "Both court type and date are required.");
			request.getRequestDispatcher("/mvc/view/client/SearchCourtView.jsp").forward(request, response);
			return;
			
		}
		
		Date date = Date.valueOf(searchDate);
		boolean ct = courtType.equals("Indoor");

		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		
		CourtDAO cm = new CourtDAO(configFile);
		ArrayList<CourtDTO> courts = new ArrayList<CourtDTO>();
		
		for(CourtDTO c : cm.requestAvailableCourtsByTypeAndDate(ct, date)) {
			if(c.getMaxNum()<maxNum) {
				courts.add(c);
			}
		}
		
		if(courts == null || courts.isEmpty())
		{
			
			request.setAttribute("message", "No courts found for the selected criteria.");
			
		}
		
		cm.destroy();
		
		request.setAttribute("courts", courts);
		
		request.getRequestDispatcher("/mvc/view/client/SearchCourtView.jsp").forward(request, response);
		
	}
	
}