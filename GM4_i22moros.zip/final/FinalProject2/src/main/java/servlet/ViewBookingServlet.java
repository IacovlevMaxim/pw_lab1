package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

import business.factories.Reservation;
import data.DAO.ReservationDAO;


/**
 * Servlet implementation class ViewBookingServlet
 */
@WebServlet("/ViewBookingServlet")
public class ViewBookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		LocalDate startDate = LocalDate.parse(request.getParameter("startDate"));
		LocalDate endDate = LocalDate.parse(request.getParameter("endDate"));

		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		
		ReservationDAO rDAO = new ReservationDAO(configFile);

		ArrayList<Reservation> completedReservations = new ArrayList<Reservation>();
		ArrayList<Reservation> futureReservations = new ArrayList<Reservation>();
		
		for(Reservation r : rDAO.getReservationBetween(endDate, startDate)){
			if(r.getDate().isAfter(LocalDate.now())) {
				futureReservations.add(r);
			} else {
				completedReservations.add(r);
			}
		}
		
		rDAO.destroy();
		
		try
		{
			request.setAttribute("completedReservations", completedReservations);
			request.setAttribute("futureReservations", futureReservations);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("mvc/view/client/BookingView.jsp");
			
			dispatcher.forward(request, response);
			
		}
		catch (Exception e)
		{
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
		}
		
		
	}

}