package servlet;

import data.DAO.ReservationDAO;
import business.FamilyReservationDTO;
import business.exceptions.NoAdultException;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;

@WebServlet("/ManageReservationServlet")
public class ManageReservationServlet extends HttpServlet
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		Integer reservationId = Integer.valueOf(request.getParameter("reservationId"));
        String action = request.getParameter("action");
        
        if (reservationId == null) 
        {
        	
            request.setAttribute("message", "Reservation ID is required.");
            request.getRequestDispatcher("/mvc/view/client/ManageReservationView.jsp").forward(request, response);
            return;
            
        }

		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
        
        ReservationDAO res = new ReservationDAO(configFile); 
        FamilyReservationDTO r = (FamilyReservationDTO) res.getReservationById(reservationId);
        
        if (r == null) 
        {
        	
            request.setAttribute("message", "Reservation not found.");
            request.getRequestDispatcher("/mvc/view/client/ManageReservationView.jsp").forward(request, response);
            return;
        
        }
        
        String message = "Reservation modified successfully.";
        if ("MODIFY".equals(action)) 
        {
            
            int adults = Integer.parseInt(request.getParameter("adults"));
            int children = Integer.parseInt(request.getParameter("children"));
            int duration = Integer.parseInt(request.getParameter("duration"));
            LocalDate date = LocalDate.parse(request.getParameter("date"));

            try {
				r.setAdultNumber(adults);
			} catch (NoAdultException e) {
				message="ERROR: There must be at least one adult";
			}
            r.setChildrenNumber(children);
            r.setDuration(duration);
            r.setDate(date);
            res.modifyReservationByUserId(reservationId, r, adults, children);
            
            request.setAttribute("message", message);
            
        }
        
        else if("CANCEL".equals(action))
        {
        	res.deleteReservationById(reservationId);
            request.setAttribute("message", "Reservation cancelled successfully.");
        	
        }
        
        else
        {
        	
            request.setAttribute("message", "Invalid action selected.");        	
        	
        }
        res.destroy();
        
        request.getRequestDispatcher("/mvc/view/client/ManageReservationView.jsp").forward(request, response);   
		
	}
	
}