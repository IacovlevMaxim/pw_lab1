package servlet;

import data.DAO.CourtDAO;
import display.CustomerBean;
import business.CourtDTO;
import business.ReservationManager;
import business.enums.CourtSize;
import business.enums.ReservationType;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToReserveException;
import business.exceptions.InvalidNumberOfPlayersException;
import business.exceptions.NoAdultException;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;


@WebServlet("/IndividualBookingServlet")
public class IndividualBookingServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		String courtType = request.getParameter("courtType");
		String bookingDate = request.getParameter("bookingDate");
		
		if(courtType == null || bookingDate == null)
		{
			
			request.setAttribute("message", "Please specify all fields.");
			request.getRequestDispatcher("/mvc/view/IdividualBookingView.jsp").forward(request, response);
			return;
			
		}
		
		java.sql.Date date = java.sql.Date.valueOf(bookingDate);
		boolean ct = courtType.equals("Indoor");

		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		
		CourtDAO cm = new CourtDAO(configFile);
		ArrayList<CourtDTO> courts = cm.requestAvailableCourtsByTypeAndDate(ct, date);
		
		cm.destroy();
		
		request.setAttribute("courts", courts);
		request.getRequestDispatcher("/mvc/view/client/IndividualBookingView.jsp").forward(request, response);
		
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		HttpSession session = request.getSession();
		CustomerBean customerBean = (CustomerBean) session.getAttribute("customerBean");
		if (customerBean == null || customerBean.getEmail().equals("")) {
			response.sendRedirect(request.getContextPath() + "/mvc/index.jsp");
		}
		
        int numParticipantsA = Integer.parseInt(request.getParameter("numParticipantsA"));
        int numParticipantsC = Integer.parseInt(request.getParameter("numParticipantsC"));
        Boolean courtType = Boolean.valueOf(request.getParameter("courtType"));
        String courtSize = request.getParameter("courtSize");
        String userId = customerBean.getEmail();
        LocalDate bookingDate = LocalDate.parse(request.getParameter("bookingDate"));
        int duration = Integer.parseInt(request.getParameter("duration"));

		CourtSize size = CourtSize.valueOf(courtSize.toUpperCase());
		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		

		ReservationManager rManager= new ReservationManager(configFile);
		
		ReservationType rType = null;
		if(size.equals(CourtSize.ADULTS)) {rType=ReservationType.ADULT;}
		else if(size.equals(CourtSize.MINIBASKET)) {rType=ReservationType.CHILDREN;}
		else if(size.equals(CourtSize.THREE_VS_THREE)) {rType=ReservationType.FAMILY;}
		String message = "Court successfully reserved!.";
		
		try {
			rManager.makeIndividualReservation(rType, userId, bookingDate, duration, numParticipantsA, numParticipantsC, courtType);
		} catch (NoAdultException e) {
			message = "ERROR: There must be at least one adult in the reservation";
		} catch (InvalidNumberOfPlayersException e) {
			message = "ERROR: Invalid number of players";
		} catch (ImpossibleToReserveException e) {
			message= "ERROR: No court fits the criteria";
		} catch (CourtNotFoundException e) {
			message= "ERROR: No court fits the criteria";
		}
		
		rManager.closeManager();
//		CourtDAO cm2 = new CourtDAO(configFile);
//		List<CourtDTO> fitting = cm2.requestFittingAvailableCourts(numParticipantsA + numParticipants, size, courtType);
//		ReservationManager rManager= new ReservationManager(configFile);

		request.setAttribute("message", message);
		request.getRequestDispatcher("/mvc/view/client/IndividualBookingView.jsp").forward(request, response);
		
	}
	
}