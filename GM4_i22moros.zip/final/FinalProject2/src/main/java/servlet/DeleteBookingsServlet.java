package servlet;


import java.io.IOException;

import business.ReservationManager;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToUnreserveException;
import business.exceptions.PackageNotFoundException;
import business.exceptions.ReservationNotFoundException;
import business.factories.Reservation;
import display.CustomerBean;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DeleteBookingsServlet")
public class DeleteBookingsServlet extends HttpServlet{

	/** Serial ID */
	private static final long serialVersionUID = 4852333670670107286L;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		CustomerBean customerBean = (CustomerBean) session.getAttribute("customerBean");
		if (customerBean == null || customerBean.getEmail().equals("")) {
			response.sendRedirect(request.getContextPath() + "/mvc/index.jsp");
		}
		
		String cName = request.getParameter("name");

		ServletContext context = getServletContext();
		String configFile = context.getRealPath(context.getInitParameter("configFile"));
		
		ReservationManager rManager = new ReservationManager(configFile);
		Boolean success = true;
		Boolean found=true;
		Boolean isPackage=false;
		Reservation r;
		
		r=rManager.getReservationsCourt(cName);
		if(r==null) {
			found=false;
		}
		else if(r.getPackageId()!=-1)
		{
			isPackage=true;
			try {
				rManager.cancelPackage(r.getPackageId());
			} catch (ImpossibleToUnreserveException e) {
				success=false;
			} catch (PackageNotFoundException e) {
				found = false;
			} catch (CourtNotFoundException e) {
				found =false;
			} catch (Exception e) {
				rManager.closeManager();
			}
		}
		else
		{
			try {
				rManager.cancelReservation(r.getId());
			} catch (ReservationNotFoundException e) {
				found=false;
			} catch (CourtNotFoundException e) {
				found=false;
			} catch (ImpossibleToUnreserveException e) {
				success=false;
			} catch (Exception e) {
				rManager.closeManager();
			}
		}

		rManager.closeManager();
		
		response.sendRedirect(request.getContextPath() + "/mvc/view/admin/DeleteBookingsView.jsp?success=" + success + "&found=" + found + "&package=" + isPackage);
	}

}
