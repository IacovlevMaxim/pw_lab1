package business.exceptions;

public class InvalidNumberOfPlayersException extends Exception {
	/**
	 * Empty constructor
	 */
	public InvalidNumberOfPlayersException() {}
	/**
	 * Sends a message
	 * @param error The message to send
	 */
	public InvalidNumberOfPlayersException(String err)
	{
		
		super(err);
		
	}
}
