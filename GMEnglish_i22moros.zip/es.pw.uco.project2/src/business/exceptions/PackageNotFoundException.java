package business.exceptions;

public class PackageNotFoundException extends Exception {
	
	/**
	 * Empty constructor
	 */
	public PackageNotFoundException() {

    }

	/**
	 * Sends a message
	 * @param error The message to send
	 */
    public PackageNotFoundException(String error) {
    	super(error);
    }
}
