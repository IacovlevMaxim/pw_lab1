package business;

import business.exceptions.NoAdultException;
import business.factories.*;

import java.time.LocalDate;

/**
 * Data transfer object for the adult reservations
 */
public class AdultReservationDTO extends Reservation {
    private int _adultNumber;

    /**
     * Empty constructor
     */
    public AdultReservationDTO() {
        super();
    }
    
    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param adultNumber Number of adults in the reservation
     * @throws NoAdultException
     */
    public AdultReservationDTO(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, int adultNumber) {
        super(id, userId, date, duration, courtId, price);
        _adultNumber = adultNumber;
    }

    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param adultNumber Number of adults in the reservation
     * @param discount Discount applied, if at all
     * @throws NoAdultException
     */
    public AdultReservationDTO(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, float discount, int adultNumber) {
        super(id, userId, date, duration, courtId, price, discount);
        _adultNumber = adultNumber;
    }

    /**
     * Sets the number of adults.
     * @param adultNumber Number of children as int.
     */
    public void setAdultNumber(int adultNumber) {
        _adultNumber = adultNumber;
    }

    /**
     * gets the number of adults.
     * @return Number of adults as int.
     */
    public int getAdultNumber() {
        return _adultNumber;
    }
    
    @Override
	public String toString() {
		String reservInfo = super.toString();
		reservInfo += "\nNumber of adults: " + this._adultNumber;
		return reservInfo;
	}
}