/**
 * 
 */
/**
 * 
 */
module es.pw.uco.project2 {
	requires java.sql;
}