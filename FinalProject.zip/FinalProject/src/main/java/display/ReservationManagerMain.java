package display;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

import business.ReservationManager;
import business.enums.ReservationType;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToReserveException;
import business.exceptions.ImpossibleToUnreserveException;
import business.exceptions.InvalidNumberOfPlayersException;
import business.exceptions.NoAdultException;
import business.exceptions.PackageNotFoundException;
import business.exceptions.ReservationNotFoundException;

/**
 * Main program for the reservations manager
 */
public class ReservationManagerMain {

	public static void main(String[] args) {
		
		String opt="1"; // OPTION FOR THE SWITCH
		Scanner sc = new Scanner(System.in); // SCANNER TO READ THE KEYBOARD
		// PARAMETERS FOR THE RESERVATION AND COURTS //
		String email, aux, cName;
		int duration=0, maxAdults=0, maxChildren=0, packageId;
		LocalDate reservation;
		boolean cType;
		ReservationType rType;
		ArrayList<Integer> aNumber = new ArrayList<Integer>(5), cNumber = new ArrayList<Integer>(), durations = new ArrayList<Integer>();
		ArrayList<LocalDate> dates = new ArrayList<LocalDate>();
		int rId=0;
		///////////////////////////////////////////////
		ReservationManager rManager = new ReservationManager();
		
		opt="1";
		while(!opt.equals("0")) // THE MENU FOR THE USER MANAGER STARTS HERE
		{
			System.out.println("\n-------------------- MENU --------------------\n");			
			System.out.println("0) Go back\n1) Make an individual reservation\n2) Make reservations within a package\n3) Cancel a reservation\n4) Modify a reservation\n5) List all reservations\n6) List all reservations within a package\n7) List reservations on a date\n8) List reservations made by user\n9) List packages\n10) Check if a court is reserved\n11) Cancel a package\n");
			System.out.println("----------------------------------------------\n\n> ");	
			opt = sc.next();
			
			switch (opt) {
				
				case "1":
					System.out.println("\nEmail of the user making the reservation: ");
					email = sc.next();
					try {
						System.out.println("What type of reservation will it be? [CHILDREN, ADULT, FAMILY]: ");
						aux = sc.next();
						rType = ReservationType.valueOf(aux.toUpperCase());
						System.out.println("Duration of the reservation [60|90|120 minutes]: ");
						duration = Integer.parseInt(sc.next());
						System.out.println("Date of the reservation: ");
						reservation = LocalDate.parse(sc.next());
						System.out.println("Insert the type of court [1-Indoors, 0-Outdoors]: ");
						aux=sc.next();
						if(aux.equals("1")){cType = true;}
						else {cType=false;}
						maxAdults=0;
						maxChildren=0;
						switch(rType) {
						case ReservationType.CHILDREN:
							System.out.println("How many children do you want to fit?");
							maxChildren = Integer.parseInt(sc.next());
							break;
						case ReservationType.ADULT:
							System.out.println("How many adults do you want to fit? ");
							maxAdults = Integer.parseInt(sc.next());
							break;
						case ReservationType.FAMILY:
							System.out.println("How many adults do you want to fit?");
							maxAdults = Integer.parseInt(sc.next());
							System.out.println("How many children do you want to fit?");
							maxChildren = Integer.parseInt(sc.next());
							break;
						}
						cName=rManager.makeIndividualReservation(rType, email, reservation, duration, maxAdults, maxChildren, cType);
						System.out.println("\nCourt " + cName + " reserved succesfully!");
					} 
					catch(NumberFormatException e)
					{
						System.out.println("\nInvalid duration of the reservation. Unable to create the reservation.\n");
					}
					catch(DateTimeParseException e) {
						System.out.println("\nInvalid date format. Unable to create the reservation\n");
					} catch (NoAdultException e) {
						e.printStackTrace();
					} catch (InvalidNumberOfPlayersException e) {
						e.printStackTrace();
					} catch (ImpossibleToReserveException e) {
						e.printStackTrace();
					} catch (CourtNotFoundException e) {
						e.printStackTrace();
					}
					break;
				case "2":
					System.out.println("\nEmail of the user making the reservation: ");
					email = sc.next();
					try {
						System.out.println("What type of package will it be? [CHILDREN, ADULT, FAMILY]: ");
						aux = sc.next();
						rType = ReservationType.valueOf(aux.toUpperCase());
						System.out.println("Insert the type of court [1-Indoors, 0-Outdoors]: ");
						aux=sc.next();
						if(aux.equals("1")){cType = true;}
						else {cType=false;}
						aNumber = new ArrayList<Integer>();
						cNumber = new ArrayList<Integer>();
						for(int i=0; i<5; i++)
						{
							System.out.println("\n-- Introduce the information for reservation " + i + " --");
							System.out.println("\nDuration of the reservation [60|90|120 minutes]: ");
							durations.add(Integer.parseInt(sc.next()));
							System.out.println("Date of the reservation: ");
							dates.add(LocalDate.parse(sc.next()));
							maxAdults=0;
							maxChildren=0;
							switch(rType) {
							case ReservationType.CHILDREN:
								System.out.println("How many children do you want to fit?");
								cNumber.add(Integer.parseInt(sc.next()));
								aNumber.add(0);
								break;
							case ReservationType.ADULT:
								System.out.println("How many adults do you want to fit? ");
								aNumber.add(Integer.parseInt(sc.next()));
								cNumber.add(0);
								break;
							case ReservationType.FAMILY:
								System.out.println("How many adults do you want to fit?");
								aNumber.add(Integer.parseInt(sc.next()));
								System.out.println("How many children do you want to fit?");
								cNumber.add(Integer.parseInt(sc.next()));
								break;
							}
							
						}
						cName=rManager.makePackageReservation(rType, email, dates, durations, aNumber, cNumber, cType);
						System.out.println("\nCourt " + cName + " reserved succesfully!");
					} 
					catch(NumberFormatException e)
					{
						System.out.println("\nInvalid duration of the reservation. Unable to create the package.\n");
					}
					catch(DateTimeParseException e) {
						System.out.println("\nInvalid date format. Unable to create the package.\n");
					} catch (NoAdultException e) {
						e.printStackTrace();
					} catch (InvalidNumberOfPlayersException e) {
						e.printStackTrace();
					} catch (ImpossibleToReserveException e) {
						e.printStackTrace();
					} catch (CourtNotFoundException e) {
						e.printStackTrace();
					}
					break;
				case "3":
					System.out.println("\nInsert the ID of the reservation: ");
					try {
						rId = Integer.valueOf(sc.next());
						rManager.cancelReservation(rId);
						System.out.println("\nReservation succesfully cancelled!");
					} catch (ReservationNotFoundException | CourtNotFoundException | ImpossibleToUnreserveException e) {
						e.printStackTrace();
					} catch(NumberFormatException e) {
						System.out.println("\nInvalid reservation ID. Unable to cancel the reservation.\n");
					}
					break;
					
				case "4":
					System.out.println("\nId of the reservation: ");
					rId = Integer.valueOf(sc.next());
					rType = rManager.getTypeOfReservation(rId);
					maxChildren =0;
					maxAdults=0;
					try {
						System.out.println("New date of the reservation: ");
						reservation = LocalDate.parse(sc.next());
						System.out.println("New duration of the reservation [60|90|120 minutes]: ");
						duration = Integer.parseInt(sc.next());
						switch(rType) {
						case ReservationType.CHILDREN:
							System.out.println("New number of children:");
							maxChildren = Integer.parseInt(sc.next());
							break;
						case ReservationType.ADULT:
							System.out.println("New number of adults:");
							maxAdults = Integer.parseInt(sc.next());
							break;
						case ReservationType.FAMILY:
							System.out.println("New number of adults:");
							maxAdults = Integer.parseInt(sc.next());
							System.out.println("New number of children:");
							maxChildren = Integer.parseInt(sc.next());
							break;
						}
						rManager.modifyReservation(rId, reservation, duration, maxAdults, maxChildren);
						System.out.println("\nReservation successfully modified!");
					}
					catch(DateTimeParseException e) {
						System.out.println("\nInvalid date format. Unable to modify the reservation\n");
					} catch (ImpossibleToUnreserveException e) {
						e.printStackTrace();
					} catch (ReservationNotFoundException e) {
						e.printStackTrace();
					} catch (ImpossibleToReserveException e) {
						e.printStackTrace();
					} catch (NoAdultException e) {
						e.printStackTrace();
					}	
					break;
					
				case "5":
					for(String s : rManager.getReservationsString(rManager.listReservations()))
					{
						System.out.println(s.toUpperCase());
					}
					break;

				case "6":
					try {
						System.out.println("\nInsert the ID of the package: ");
						packageId = Integer.parseInt(sc.next());
						for(String s : rManager.getReservationsString(rManager.listPackageReservations(packageId)))
						{
							System.out.println(s.toUpperCase());
						}
					} 
					catch(NumberFormatException e)
					{
						System.out.println("\nInvalid duration of the reservation. Unable to create the reservation.\n");
					}
					break;
				case "7":
					try {
						System.out.println("\nDate of the reservation to consult >> ");
						reservation = LocalDate.parse(sc.next());
						for(String s : rManager.getReservationsString(rManager.getReservationsDate(reservation)))
						{
							System.out.println(s.toUpperCase());
						}
					}
					catch(DateTimeParseException e) {
						System.out.println("\nInvalid date format. Unable to list the reservations.\n");
					}	
					break;
				case "8":
					System.out.println("\nEmail of the user who made the reservation: ");
					email = sc.next();
					for(String s : rManager.getReservationsString(rManager.getReservationsUser(email)))
					{
						System.out.println(s.toUpperCase());
					}
					break;
					
				case "9":
					for(String s : rManager.getPackageString(rManager.listPackages()))
					{
						System.out.println(s.toUpperCase());
					}
					break;
					
				case "10":
					System.out.println("\nName of the court to check: ");
					cName=sc.next();
					cName+=sc.nextLine();
					if(rManager.getReservationsCourt(cName)!=null)
					{
						System.out.println("\n-- This court is currently reserved --");
						System.out.println(rManager.getReservationsCourt(cName).toString().toUpperCase());
					}
					else{
						System.out.println("\nCourt currently not reserved.\n");
					}
					break;
				case "11":
					System.out.println("\nInsert the ID of the package: ");
					try {
						rId = Integer.valueOf(sc.next());
						rManager.cancelPackage(rId);
						System.out.println("\nPackage reservations succesfully cancelled!");
					} catch (CourtNotFoundException | ImpossibleToUnreserveException | PackageNotFoundException e) {
						e.printStackTrace();
					} catch(NumberFormatException e) {
						System.out.println("\nInvalid package ID. Unable to delete the reservations.\n");
					} 
					break;	
					
				case "0":
					break;
				default:
					System.out.println("\n~ Opcion no valida ~\n\n");			
					break;
			}
		}
	}

}
