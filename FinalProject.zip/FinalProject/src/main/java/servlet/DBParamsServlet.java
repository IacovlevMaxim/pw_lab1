package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletConfig;


public class DBParamsServlet extends HttpServlet {

	private ServletContext context=null;
	
	/**
	 * Initializes the context
	 */
	public void init() {
		context = getServletContext();
	}
	
	/**
	 * Get a initialization parameter for the database
	 */
	public String getInitParameter (String name) {
		String param = context.getInitParameter(name);
		return param;
	}
	
	public void destroy() {
		context=null;
	}


}
