package business;

import business.exceptions.NoAdultException;
import business.factories.*;

import java.time.LocalDate;
/**
 * Data transfer object for the family reservations
 */
public class FamilyReservationDTO extends Reservation {

	private int _childrenNumber;
    private int _adultNumber;

    /**
     * Empty contructor
     */
    public FamilyReservationDTO() {
        super();
    }

    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param childrenNumber Number of children in the reservation
     * @param adultNumber Number of adults in the reservation
     * @throws NoAdultException
     */
    public FamilyReservationDTO(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, int childrenNumber, int adultNumber) throws NoAdultException {
        super(id, userId, date, duration, courtId, price);
        _childrenNumber = childrenNumber;
        if(adultNumber < 1) {
            throw new NoAdultException("FamilyReservation must include at least one adult");
        }

        _adultNumber = adultNumber;
    }

    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param childrenNumber Number of children in the reservation
     * @param adultNumber Number of adults in the reservation
     * @param discount Discount applied, if at all
     * @throws NoAdultException
     */
    public FamilyReservationDTO(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, float discount, int childrenNumber, int adultNumber) throws NoAdultException  {
        super(id, userId, date, duration, courtId, price, discount);
        _childrenNumber = childrenNumber;

        if(adultNumber < 1) {
            throw new NoAdultException("FamilyReservation must include at least one adult");
        }

        _adultNumber = adultNumber;
    }

    /**
     * Sets the number of children.
     * @param childrenNumber Number of children as int.
     */
    public void setChildrenNumber(int childrenNumber) {
        _childrenNumber = childrenNumber;
    }

    /**
     * gets the number of children.
     * @return Number of children as int.
     */
    public int getChildrenNumber() {
        return _childrenNumber;
    }

    /**
     * Sets the number of adults.
     * @param adultNumber Number of adults as int.
     */
    public void setAdultNumber(int adultNumber) throws NoAdultException {
        if(adultNumber < 1) {
            throw new NoAdultException("FamilyReservation must include at least one adult");
        }

        _adultNumber = adultNumber;
    }

    /**
     * gets the number of adults.
     * @return Number of adults as int.
     */
    public int getAdultNumber() {
        return _adultNumber;
    }


	@Override
	public String toString() {
		String reservInfo = super.toString();
		reservInfo += "\nNumber of children: " + this._childrenNumber + 
		"\nNumber of adults: " + this._adultNumber;

		return reservInfo;
	}
    
    

}