package business.factories;

import java.time.LocalDate;

/**
 * Reservation class
 */
abstract public class Reservation {
	private Integer id;
	private Integer _userId;
    private LocalDate _date;
    private int _duration;
    private Integer _courtId;
    private float _price;
    private float _discount;
    private Integer _packageId;
    private int _sessionNumber;

    /**
     * Empty constructor
     */
    public Reservation() {

    }

    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     */
    public Reservation(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price) {
        this.id = id;
    	_userId = userId;
        _date = date;
        _duration = duration;
        _courtId = courtId;
        _price = price;
        _discount = 0;
        this._packageId=-1;
        this._sessionNumber=-1;
    }


    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param discount Discount applied, if at all
     */
    public Reservation(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, float discount) {
        this.id = id;
    	_userId = userId;
        _date = date;
        _duration = duration;
        _courtId = courtId;
        _price = price;
        _discount = discount;
        this._packageId=-1;
        this._sessionNumber=-1;
    }

    /**
     * Gets the user ID of the reservation.
     * @return The user ID as a String.
     */
    public Integer getUserId() {
        return _userId;
    }

    /**
     * Sets the user ID for the reservation.
     * @param userId The user ID as a String.
     */
    public void setUserId(Integer userId) {
        _userId = userId;
    }

    /**
     * Gets the date of the reservation.
     * @return The reservation date as a LocalDate object.
     */
    public LocalDate getDate() {
        return _date;
    }

    /**
     * Gets the ID of the reservation
     * @return The ID of the reservation as an Integer
     */
    public Integer getId() {
		return id;
	}

    /**
     * Sets the ID for the reservation
     * @param id The new ID for the reservation
     */
	public void setId(Integer id) {
		this.id = id;
	}

    /**
     * Sets the date for the reservation.
     * @param date The reservation date as a LocalDate object.
     */
    public void setDate(LocalDate date) {
        _date = date;
    }

    /**
     * Gets the duration of the reservation.
     * @return The duration in hours as an int.
     */
    public int getDuration() {
        return _duration;
    }

    /**
     * Sets the duration for the reservation.
     * @param duration The duration in hours as an int.
     */
    public void setDuration(int duration) {
        _duration = duration;
    }

    /**
     * Gets the court ID of the reservation.
     * @return The court ID as a String.
     */
    public Integer getCourtId() {
        return _courtId;
    }

    /**
     * Sets the court ID for the reservation.
     * @param courtId The court ID as a String.
     */
    public void setCourtId(Integer courtId) {
        _courtId = courtId;
    }

    /**
     * Gets the price of the reservation.
     * @return The price as a float.
     */
    public float getPrice() {
        return _price;
    }

    /**
     * Sets the price for the reservation.
     * @param price The price as a float.
     */
    public void setPrice(float price) {
        _price = price;
    }

    /**
     * Gets the discount applied to the reservation.
     * @return The discount as a float.
     */
    public float getDiscount() {
        return _discount;
    }

    /**
     * Sets the discount for the reservation.
     * @param discount The discount as a float.
     */
    public void setDiscount(float discount) {
        _discount = discount;
    }

    /**
     * Sets the package ID for the reservation in case of package reservation.
     * @param packageId The package ID as a string.
     */
    public void setPackageId(Integer packageId) {
        _packageId = packageId;
    }

    /**
     * Gets the package ID of the reservation.
     * @return Package ID as string.
     */
    public Integer getPackageId() {
        return _packageId;
    }

    /**
     * Sets the session number for the reservation in case of package reservation.
     * @param sessionNumber The session number as an int.
     */
    public void setSessionNumber(int sessionNumber) {
        _sessionNumber = sessionNumber;
    }

    /**
     * Gets the session number for the reservation.
     * @return Session number as int.
     */
    public int getSessionNumber() {
        return _sessionNumber;
    }

    @Override
    public String toString() {
    	String reservationInfo;
    	
        reservationInfo = "\nReservation ID: " + this.id + "\nUser ID: " + _userId + '\n' +
        "Date of the reservation: " + _date +
        "\nDuration: " + _duration +
        " minutes\nCourt ID: " + _courtId + '\n' +
        "Price: " + _price +
        " euros\nDiscount: " + _discount;
        if(this._packageId!=-1)
        {
        	reservationInfo +=  "\nPackage ID: " + _packageId + '\n' +
        "Session within the package: " + _sessionNumber;
        }
        return reservationInfo;
    }
}