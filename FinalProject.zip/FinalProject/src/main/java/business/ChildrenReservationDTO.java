package business;

import business.exceptions.NoAdultException;
import business.factories.*;

import java.time.LocalDate;
/**
 * Data transfer object for the children reservations
 */
public class ChildrenReservationDTO extends Reservation {
    private int _childrenNumber;

    /**
     * Empty constructor
     */
    public ChildrenReservationDTO() {
        super();
    }
    
    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param childrenNumber Number of children in the reservation
     * @throws NoAdultException
     */
    public ChildrenReservationDTO(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, int childrenNumber) {
        super(id, userId, date, duration, courtId, price);
        _childrenNumber = childrenNumber;
    }

    /**
     * Parameterized constructor
     * @param id ID of the reservation
     * @param userId ID of the user who made the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @param courtId ID of the reserved court
     * @param price Price of the reservation
     * @param childrenNumber Number of children in the reservation
     * @param discount Discount applied, if at all
     * @throws NoAdultException
     */
    public ChildrenReservationDTO(Integer id, Integer userId, LocalDate date, int duration, Integer courtId, float price, float discount, int childrenNumber) {
        super(id, userId, date, duration, courtId, price, discount);
        _childrenNumber = childrenNumber;
    }

    /**
     * Sets the number of children.
     * @param childrenNumber Number of children as int.
     */
    public void setChildrenNumber(int childrenNumber) {
        _childrenNumber = childrenNumber;
    }

    /**
     * gets the number of children.
     * @return Number of children as int.
     */
    public int getChildrenNumber() {
        return _childrenNumber;
    }
    
    @Override
	public String toString() {
		String reservInfo = super.toString();
		reservInfo += "\nNumber of children: " + this._childrenNumber;

		return reservInfo;
	}
}