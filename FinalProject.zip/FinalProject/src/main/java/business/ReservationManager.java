package business;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import business.enums.CourtSize;
import business.enums.ReservationType;
import business.exceptions.CourtNotFoundException;
import business.exceptions.ImpossibleToReserveException;
import business.exceptions.ImpossibleToUnreserveException;
import business.exceptions.InvalidNumberOfPlayersException;
import business.exceptions.NoAdultException;
import business.exceptions.PackageNotFoundException;
import business.exceptions.ReservationNotFoundException;
import business.factories.Reservation;
import data.DAO.*;

/**
 * Manager for the reservations and the packages
 */
public class ReservationManager {
	private PlayerDAO playerDB;
	private CourtDAO courtDB;
	private ReservationDAO reservationDB;
	private PackageDAO packageDB;

    /**
     * Empty constructor
     */
    public ReservationManager() {
        this.packageDB=new PackageDAO();
        this.courtDB=new CourtDAO();
        this.playerDB=new PlayerDAO();
        this.reservationDB=new ReservationDAO();
    }

    
    /**
     * Calculates the price based on the duration of the reservation.
     *
     * @param duration the duration of the reservation in minutes. Valid values are 60, 90, and 120.
     * @return the price corresponding to the given duration. Returns 20.0 for 60 minutes, 
     *         30.0 for 90 minutes, 40.0 for 120 minutes, and 0.0 for any other duration.
     */
    private float calculatePrice(int duration) {
        switch (duration) {
            case 60: return 20.0f;
            case 90: return 30.0f;
            case 120: return 40.0f;
            default: return 0.0f; 
        }
    }

    /**
     * Calculates the discount based on the user's seniority.
     *
     * @param userId the ID of the user
     * @return the discount percentage. Returns 10.0 for users with seniority greater than 2 years, and 0.0 otherwise.
     */
    private float calculateDiscount(PlayerDTO player, float price) {
    	if(player.calculateSeniority()>2)
    	{
    		 return (float) ((0.10)*price);
    	}
        return 0.0f;
    }

    /**
     * Checks if the given date is valid for making a reservation.
     *
     * @param date the date of the reservation
     * @return {@code true} if the date is at least 24 hours in the future, and {@code false} otherwise
     */
    private boolean isValidReservationDate(LocalDate date) {
        if(ChronoUnit.DAYS.between(LocalDate.now(), date) > 1) {
            return true;
        }
        return false;
    }
 
    /**
     * Checks if the reservation follows all the restrictions
     * @param player PlayerDTO making the reservation
     * @param maxNum Number of players to fit in the reservation
     * @param date Date of the reservation
     * @param duration Duration of the reservation
     * @return The price of the reservation, if it passed all the restrictions
     * @throws InvalidNumberOfPlayersException
     * @throws ImpossibleToReserveException
     */
    public float checkCriteria(PlayerDTO player, ArrayList<Integer> maxNum, ArrayList<LocalDate> date, int duration) throws InvalidNumberOfPlayersException, ImpossibleToReserveException {

    	float price=0;
        if(player==null) {
        	throw new ImpossibleToReserveException("The user making the reservation must be logged. Unable to reserve.\n");
        }
        for(Integer i : maxNum)
        	{
        		if(i<1)
        		{
        			throw new InvalidNumberOfPlayersException("There must be at least one player in the reservation. Unable to reserve.\n");
        		}
        	}
        for(LocalDate d : date)
        {
            if(!isValidReservationDate(d)) {
            	throw new ImpossibleToReserveException("Reservation cannot be made less than 24 hours before the start date. Unable to reserve.\n");
            }
        }
        if((price = calculatePrice(duration)) == 0) {
        	throw new ImpossibleToReserveException("Invalid time for reservation (Valid values: 60, 90, 120). Unable to reserve.\n");
        }
        return price;
    }
    
    
    
    /**
     * Makes an individual reservation for the specified user.
     *
     * @param rType Type of reservation to make
     * @param userId the ID of the user
     * @param date the date of the reservation
     * @param duration the duration of the reservation in minutes
     * @param adult_number the maximum number of adults allowed in the court
     * @param children_number the maximum number of children allowed in the court
     * @param type the type of the court we want to reserve (indoor or outdoor)
     * @return The name of the reserved court, if found, null if no available court fits the criteria
     * @throws NoAdultException 
     * @throws InvalidNumberOfPlayersException 
     * @throws ImpossibleToReserveException 
     * @throws CourtNotFoundException 
     */
    public String makeIndividualReservation(ReservationType rType, String userId, LocalDate date, int duration, int adult_number, int children_number, boolean type) throws NoAdultException, InvalidNumberOfPlayersException, ImpossibleToReserveException, CourtNotFoundException {

    	String name=null;
        float price, discount;
        PlayerDTO player;
        CourtDTO court;
        ArrayList <CourtDTO> availableCourts = new ArrayList <CourtDTO>();
        int max_num=adult_number + children_number;
        player=playerDB.requestPlayerByEmail(userId);
        CourtSize size;
        if(adult_number<1 && rType==ReservationType.FAMILY) {
        	throw new NoAdultException("Reservation must include at least one adult. Unable to reserve.\n");
        }
        if(rType==ReservationType.CHILDREN) {size=CourtSize.MINIBASKET;}
        else if(rType==ReservationType.ADULT) {size=CourtSize.ADULTS;}
        else {size=CourtSize.THREE_VS_THREE;}
        availableCourts=courtDB.requestFittingAvailableCourts(max_num, size, type);
        if(availableCourts.size()==0)
        {
        	throw new ImpossibleToReserveException("No available court fit that criteria. Unable to reserve.\n");
        }
        court=availableCourts.get(0);
        ArrayList<Integer> aux = new ArrayList<Integer>();
        aux.add(max_num);
        ArrayList<LocalDate> dates = new ArrayList<LocalDate>();
        dates.add(date);
        price = checkCriteria(player, aux, dates, duration);
        
        discount = (float)calculateDiscount(player, price);
        int uId = playerDB.getPlayerId(userId);
        int cId = courtDB.getCourtId(court.getName());
    	courtDB.reserveCourtByName(court.getName());
        name=court.getName();
        
        switch(rType)
        {
        case ReservationType.CHILDREN:
            reservationDB.insertReservation(new ChildrenReservationDTO(null, uId, date, duration, cId, price, discount, children_number));
            break;
        case ReservationType.ADULT:
            reservationDB.insertReservation(new AdultReservationDTO(null,uId, date, duration, cId, price, discount, adult_number));
            break;
        case ReservationType.FAMILY: 
            reservationDB.insertReservation(new FamilyReservationDTO(null, uId, date, duration, cId, price, discount, children_number, adult_number));
            break;
        }
        return name;
    }
    
    /**
     * Makes a package reservation for the specified user.
     *
     * @param rType Type of reservation to make
     * @param userId the ID of the user
     * @param date List of dates for each reservation
     * @param duration List of durations for each reservation
     * @param adult_number List with the maximum number of adults allowed in the court for each reservation
     * @param children_number List with the maximum number of children allowed in the court for each reservation
     * @param type the type of the court we want to reserve (indoor or outdoor)
     * @return The name of the reserved court, if found, null if no available court fits the criteria
     * @throws NoAdultException 
     * @throws InvalidNumberOfPlayersException 
     * @throws ImpossibleToReserveException 
     * @throws CourtNotFoundException 
     */
    public String makePackageReservation(ReservationType rType, String userId, ArrayList<LocalDate> date, ArrayList<Integer> duration, ArrayList<Integer> adult_number, ArrayList<Integer> children_number, boolean type) throws NoAdultException, CourtNotFoundException, ImpossibleToReserveException, InvalidNumberOfPlayersException {

    	String name=null;
    	ArrayList<Float> prices = new ArrayList<Float>(), discounts = new ArrayList<Float>();
        float price=0;
        int maxNum=0;
        CourtDTO court = null;
        ArrayList<Integer> max_num = new ArrayList<Integer>();
        for(int i=0; i<5; i++)
        {
        	max_num.add(adult_number.get(i) + children_number.get(i));
        	if(max_num.get(i)>maxNum){maxNum=max_num.get(i);}
            if(rType==ReservationType.FAMILY && adult_number.get(i)<1) {
            	throw new NoAdultException("Reservation must include at least one adult. Unable to reserve.\n");
            }
        }
        CourtSize size;
        if(rType==ReservationType.CHILDREN) {size=CourtSize.MINIBASKET;}
        else if(rType==ReservationType.ADULT) {size=CourtSize.ADULTS;}
        else {size=CourtSize.THREE_VS_THREE;}

        ArrayList<CourtDTO> availableCourts=courtDB.requestFittingAvailableCourts(maxNum, size, type);
        if(availableCourts.size()==0)
        {
        	throw new ImpossibleToReserveException("No available court fit that criteria. Unable to reserve.\n");
        }
        court = availableCourts.get(0);
        name=court.getName();
        PlayerDTO player=playerDB.requestPlayerByEmail(userId);
        checkCriteria(player, max_num, date, duration.get(0));
        for(Integer d : duration)
        {
        	price=calculatePrice(d);
        	prices.add(price);
        	discounts.add((float)(price*0.05));
        }

    	courtDB.reserveCourtByName(court.getName());
        int uId = playerDB.getPlayerId(userId);
        int cId = courtDB.getCourtId(court.getName());
    	int packageId=packageDB.addNewPackage(new PackageDTO(uId, date.get(0)));
    	
        switch(rType)
        {
        case ReservationType.CHILDREN:
        	for(int i=0; i<5; i++)
        	{
        		ChildrenReservationDTO cR = new ChildrenReservationDTO(null, uId, date.get(i), duration.get(i), cId, prices.get(i), discounts.get(i), children_number.get(i));
            	cR.setSessionNumber(i);
            	cR.setPackageId(packageId);
        		reservationDB.insertReservation(cR);
        	}
            break;
        case ReservationType.ADULT:
        	for(int i=0; i<5; i++)
        	{
        		AdultReservationDTO aR = new AdultReservationDTO(null, uId, date.get(i), duration.get(i), cId, prices.get(i), discounts.get(i), adult_number.get(i));
            	aR.setSessionNumber(i);
            	aR.setPackageId(packageId);
        		reservationDB.insertReservation(aR);
        	}
        	break;
        case ReservationType.FAMILY: 
        	for(int i=0; i<5; i++)
        	{
            	FamilyReservationDTO fR = new FamilyReservationDTO(null, uId, date.get(i), duration.get(i), cId, prices.get(i), discounts.get(i), children_number.get(i), adult_number.get(i));
            	fR.setSessionNumber(i);
            	fR.setPackageId(packageId);
                reservationDB.insertReservation(fR);
        	}
            break;
        }
        return name;
    }

    
    /**
     * Cancels a reservation for a given user and court.
     *
     * @param rId ID of the reservation
     * @return {@code true} if the reservation was successfully canceled, {@code false} otherwise.
     * The reservation can only be canceled if it is more than 24 hours before the start date.
     * If the reservation is less than 24 hours before the start date, a message will be printed
     * and the cancellation will not proceed.
     * @throws ImpossibleToReserveException 
     * @throws CourtNotFoundException 
     * @throws ImpossibleToUnreserveException 
     */
    @SuppressWarnings("unused")
	public void cancelReservation(Integer rId) throws ReservationNotFoundException, CourtNotFoundException, ImpossibleToUnreserveException {
    	Reservation r = reservationDB.getReservationById(rId);
    	if(r.getPackageId()!=-1)
    	{
    		throw new ImpossibleToUnreserveException("This reservation belongs to a package. Unable to cancel reservation.\n");
    	}
    	if(r==null)
    	{
    		throw new ReservationNotFoundException("Unable to find a reservation with that ID. Unable to cancel reservation.\n");
    	}
        if(!isValidReservationDate(r.getDate())) {
        	throw new ImpossibleToUnreserveException("Reservation cannot be cancelled less than 24 hours before the start date. Unable to cancel reservation.\n");
        }
    	Integer courtId = r.getCourtId();
    	reservationDB.deleteReservationById(rId);
    	courtDB.unreserveCourtById(courtId);
    }
    
    /**
     * Cancels a package and all of its reservations
     * @param pId ID of the package
     * @throws ImpossibleToUnreserveException
     * @throws PackageNotFoundException
     * @throws CourtNotFoundException
     */
    public void cancelPackage(Integer pId) throws ImpossibleToUnreserveException, PackageNotFoundException, CourtNotFoundException {
    	PackageDTO pack = packageDB.requestPackageById(pId);
    	if(pack==null)
    	{
    		throw new PackageNotFoundException("Unable to find a package with that ID. Unable to cancel package reservations.\n");
    	}
        if(!isValidReservationDate(pack.getStartDate())) {
        	throw new ImpossibleToUnreserveException("Packages cannot be cancelled less than 24 hours before the start date. Unable to cancel package reservations.\n");
        }
        Integer courtId = reservationDB.getReservationByPackageId(pId).get(0).getCourtId();
    	reservationDB.deleteReservationByPackageId(pId);
    	packageDB.deletePackage(pId);
    	courtDB.unreserveCourtById(courtId);
    }

    /**
     * Modifies a reservation for a given user and court.
     *
     * @param rId ID of the reservation to modify
     * @param newDate the new date of the reservation
     * @param newDuration the new duration of the reservation in minutes
     * @param newChildrenNumber the new number of children in the reservation
     * @param newAdultNumber the new number of adults in the reservation
     * @return {@code true} if the reservation was successfully modified, {@code false} otherwise.
     * The reservation can only be modified if it is more than 24 hours before the start date.
     * If the reservation is less than 24 hours before the start date, a message will be printed
     * and the modification will not proceed.
     * @throws ImpossibleToUnreserveException 
     * @throws ReservationNotFoundException 
     * @throws ImpossibleToReserveException 
     * @throws NoAdultException 
     */
	public boolean modifyReservation(Integer rId, LocalDate newDate, int newDuration, int newChildrenNumber, int newAdultNumber) throws ImpossibleToUnreserveException, ReservationNotFoundException, ImpossibleToReserveException, NoAdultException {
    	ReservationType rType = reservationDB.getReservationTypeById(rId);
    	Reservation r = reservationDB.getReservationById(rId);
    	PlayerDTO player = playerDB.requestPlayerById(r.getUserId());
    	if(r.getPackageId()!=-1)
    	{
    		throw new ImpossibleToUnreserveException("Package reservation cannot be modified. Unable to modify reservation.\n");
    	}
    	if(rType==null)
    	{
    		throw new ReservationNotFoundException("Unable to find a reservation with that ID. Unable to modify reservation.\n");
    	}
    	int maxNum= newChildrenNumber+newAdultNumber;
    	if(maxNum<1)
    	{
    		throw new ImpossibleToReserveException("The modified reservation must have at least one player. Unable to modify reservation.\n");
    	}
    	if(rType.equals(ReservationType.FAMILY) && newAdultNumber<1)
    	{
    		throw new NoAdultException("Reservation must include at least one adult. Unable to modify reservation.\n");
    	}
        if(!isValidReservationDate(r.getDate())) {
        	throw new ImpossibleToUnreserveException("Reservation cannot be modified less than 24 hours before the start date. Unable to modify reservation.\n");
        }
        if(!isValidReservationDate(newDate)) {
        	throw new ImpossibleToUnreserveException("Reservation cannot be modified to less than 24 hours before the start date. Unable to modify reservation.\n");
        }
        float newPrice = calculatePrice(newDuration);
        float discount = this.calculateDiscount(player, newPrice);
    	r.setDate(newDate);
    	r.setDuration(newDuration);
    	r.setDiscount(discount);
    	reservationDB.modifyReservationByUserId(rId, r, newAdultNumber, newChildrenNumber);
        return false;
    }

	/**
	 * Gets the type of a reservation
	 * @param id ID of the reservation to get the type from
	 * @return The type of reservation
	 */
	public ReservationType getTypeOfReservation(Integer id) {
        ReservationType type = reservationDB.getReservationTypeById(id);
        return type;
    }

    /**
     * Retrieves a list of reservations for a specific date 
     * @param date The date for which reservations are to be retrieved.
     * @return An ArrayList of Reservation objects that match the specified date.
     */
    public ArrayList<Reservation> getReservationsDate(LocalDate date) {
        ArrayList<Reservation> res = reservationDB.getReservationByDate(date);
        return res;
    }
    
    /**
     * Retrieves the reservation for a specific court
     * @param courtId ID of the reserved court
     * @return The reservation
     */
    public Reservation getReservationsCourt(String courtId) {
    	Integer id = courtDB.getCourtId(courtId);
    	if(id==null)
    	{
    		return null;
    	}
        Reservation res = reservationDB.getReservationByCourtId(id);
        return res;
    }
    
    /**
     * Retrieves the list of reservations for a specific user
     * @param userId ID of the reserved court
     * @return The list of reservations for that user
     */
    public ArrayList<Reservation> getReservationsUser(String userId) {
    	int uId = playerDB.getPlayerId(userId);
    	ArrayList<Reservation> res = reservationDB.getReservationByUserId(uId);
        return res;
    }
    
    /**
     * List the reservations
     * @return The list of reservations
     */
    public ArrayList<Reservation>listReservations() {
        ArrayList<Reservation> res = reservationDB.getReservations();
        return res;
    }
    
    /**
     * List all packages 
     * @return The list of packages
     */
    public ArrayList<PackageDTO>listPackages() {
        ArrayList<PackageDTO> res = packageDB.requestAllPackages();
        return res;
    }
    
    /**
     * List all reservations within a package
     * @param packageId The ID of the package
     * @return The list with all the reservations in the package
     */
    public ArrayList<Reservation>listPackageReservations(Integer packageId) {
        ArrayList<Reservation> res = reservationDB.getReservationByPackageId(packageId);
        return res;
    }
    
   /**
    * List all reservations of a specific type
    * @param type Type of the reservation
    * @return The list with the reservations
    */
    public ArrayList<Reservation>listTypeReservations(ReservationType type) {
        ArrayList<Reservation> res = reservationDB.getReservationsByType(type);
        return res;
    }
    
    /**
     * Checks if an user is an adult (>18 years) or not
     * @param user User to check
     * @return True if adult, false if not
     */
    public boolean isAdult(PlayerDTO user)
    {
    	LocalDate adult = user.getBirth().plusYears(18);
    	if(adult.isBefore(LocalDate.now())) {
    		return true;
    	}
    	return false;
    }
    
    /**
	 * List of to string methods for a list of reservations
	 * @param reservation The list of reservation to get the to string methods from
	 * @return The list of strings
	 */
    public ArrayList<String> getReservationsString(ArrayList<Reservation> reservations)
	{
		ArrayList<String> reservationsText = new ArrayList<String>();
		for(Reservation r: reservations) {
			reservationsText.add(r.toString());
		}
		return reservationsText;
	}
    
    /**
	 * List of to string methods for a list of packages
	 * @param packages The list of packages to get the to string methods from
	 * @return The list of strings
	 */
    public ArrayList<String> getPackageString(ArrayList<PackageDTO> packages)
	{
		ArrayList<String> packagesText = new ArrayList<String>();
		for(PackageDTO p: packages) {
			packagesText.add(p.toString());
		}
		return packagesText;
	}
}
