package business.exceptions;

public class NoAdultException extends Exception {
    /**
     * Empty constructor
     */
	public NoAdultException() {

    }
	/**
	 * Sends a message
	 * @param error The message to send
	 */
    public NoAdultException(String message) {
        super(message);
    }
}