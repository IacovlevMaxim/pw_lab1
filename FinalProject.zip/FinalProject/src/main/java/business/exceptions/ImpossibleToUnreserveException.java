package business.exceptions;

/**
 * Exception for when a court or material cannot be reserved
 */
public class ImpossibleToUnreserveException extends Exception {
	/**
	 * Empty constructor
	 */
	public ImpossibleToUnreserveException() {

    }

	/**
	 * Sends a message
	 * @param error The message to send
	 */
    public ImpossibleToUnreserveException(String error) {
    	super(error);
    }
}