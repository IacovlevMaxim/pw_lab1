package business.enums;

/**
 * Types of reservation
 */
public enum ReservationType {
    ADULT,
    CHILDREN,
    FAMILY
}