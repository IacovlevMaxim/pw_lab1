package data.DAO; 

import business.AdultReservationDTO;
import business.ChildrenReservationDTO;
import business.FamilyReservationDTO;
import business.enums.ReservationType;
import business.exceptions.ReservationNotFoundException;
import data.common.DBConnection;
import data.common.QueriesLoader;
import business.factories.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Data access object for the reservations
 */
public class ReservationDAO {
    QueriesLoader loader;
    IndividualReservationFactory individualFactory;
    PackageReservationFactory packageFactory;
    Connection connection;
    
    /**
     * Empty constructor
     */
    public ReservationDAO() {
        loader = new QueriesLoader();
        individualFactory = new IndividualReservationFactory();
        packageFactory = new PackageReservationFactory();
        connection = new DBConnection().getConnection();
    }

    /**
     * Destroys the connection to the database
     */
    public void destroy() {
        try {
            if(this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch(Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
    }

    /**
     * Creates the specific reservation object from a result set
     * @param rs The result set of a previous query
     * @return The created reservation
     * @throws Exception
     */
    private Reservation _reservationFromDb(ResultSet rs) throws Exception {
    	Integer id = rs.getInt("id");
        boolean hasPackageId = rs.getInt("packageId") != -1;
        Integer userId = rs.getInt("userId");
        LocalDate date = rs.getDate("date").toLocalDate();
        int duration = rs.getInt("duration");
        Integer courtId = rs.getInt("courtId");
        float price = rs.getFloat("price");
        float discount = rs.getFloat("discount");
        int adultNumber = rs.getInt("adultNumber");
        int childrenNumber = rs.getInt("childrenNumber");
        Integer packageId = rs.getInt("packageId");
        int sessionNumber = rs.getInt("sessionNumber");
        ReservationType type = ReservationType.valueOf(rs.getString("type"));

        return switch (type) {
            case ADULT -> hasPackageId
                    ? packageFactory.createAdultReservation(id, userId, date, duration, courtId, price, discount, adultNumber, packageId, sessionNumber)
                    : individualFactory.createAdultReservation(id, userId, date, duration, courtId, price, discount, adultNumber);
            case CHILDREN -> hasPackageId
                    ? packageFactory.createChildrenReservation(id,userId, date, duration, courtId, price, discount, adultNumber, packageId, sessionNumber)
                    : individualFactory.createChildrenReservation(id, userId, date, duration, courtId, price, discount, adultNumber);
            case FAMILY -> hasPackageId
                    ? packageFactory.createFamilyReservation(id, userId, date, duration, courtId, price, discount, adultNumber, childrenNumber, packageId, sessionNumber)
                    : individualFactory.createFamilyReservation(id, userId, date, duration, courtId, price, discount, adultNumber, childrenNumber);
        };
    }

    /**
     * Gets a reservation using a specific query and parameter
     * @param id ID to use to get the reservation
     * @param query Query used to get the reservation
     * @return The reservation
     */
    private Reservation _getReservationByQuery(Integer id, String query){
        Reservation player = null;
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty(query));
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if(!rs.next()) {
                return null;
            }

            player = _reservationFromDb(rs);
            stmt.close();
            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
        return player;
    }

    /**
     * Gets the reservation using the Reservation ID
     * @param id ID of the reservation
     * @return The reservation
     */
    public Reservation getReservationById(Integer id) {
        return _getReservationByQuery(id, "ReservationIdFilter");
    }
    
    /**
     * Gets the reservations made by the user ID
     * @param userId ID of the user who made the reservations
     * @return The list of reservations
     */
    public ArrayList<Reservation> getReservationByUserId(Integer userId) {
    	ArrayList<Reservation> reservations = new ArrayList<Reservation>();
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ReservationUserIdFilter"));
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                reservations.add(_reservationFromDb(rs));
            }

            stmt.close();

            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
        return reservations;
    }
    
    /**
     * Gets the next reservation made by the user with that ID
     * @param userId ID of the user who made the reservation
     * @return The next reservation
     */
    public Reservation getNextReservationByUserId(Integer userId) {
    	Reservation reservation = null;
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("findNearestReservation"));
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if(!rs.next()) {
            	return null;
            }

            reservation=_reservationFromDb(rs);

            stmt.close();

            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
        return reservation;
    }
    
    /**
     * Gets the first reservation made by the user with that ID
     * @param userId ID of the user who made the reservation
     * @return The user's first reservation
     */
    public Reservation getFirstReservationByUserId(Integer userId) {
    	Reservation reservation = null;
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("findFirstReservation"));
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if(!rs.next()) {
            	return null;
            }

            reservation=_reservationFromDb(rs);

            stmt.close();

            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
        return reservation;
    }

    /**
     * Gets the reservations in a package
     * @param packageId ID of the package 
     * @return The list of reservations
     */
    public ArrayList<Reservation> getReservationByPackageId(Integer packageId) {
    	ArrayList<Reservation> reservations = new ArrayList<Reservation>();
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ReservationPackageIdFilter"));
            stmt.setInt(1, packageId);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                reservations.add(_reservationFromDb(rs));
            }

            stmt.close();

            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
        return reservations;
    }
    
    /**
     * Gets the reservations for that date
     * @param date Date to search
     * @return The list of reservations on that date
     */
    public ArrayList<Reservation> getReservationByDate(LocalDate date) {
    	ArrayList<Reservation> reservations = new ArrayList<Reservation>();
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ReservationDateFilter"));
            stmt.setDate(1, Date.valueOf(date));
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                reservations.add(_reservationFromDb(rs));
            }

            stmt.close();

            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
        return reservations;
    }

    /**
     * Gets the reservation using the reserved court
     * @param courtID ID of the reserved court
     * @return The reservation for that court
     */
    public Reservation getReservationByCourtId(Integer courtId) {
        return _getReservationByQuery(courtId, "ReservationCourtIdFilter");
    }
    
    /**
     * Prepares the basic parameters to perform a statement
     * @param reservation Reservation with the parameters
     * @param query Query to perform
     * @return The preparedStatement
     * @throws Exception
     */
    private PreparedStatement _prepareBaseStatement(Reservation reservation, String query) throws Exception {
        PreparedStatement stmt = connection.prepareStatement(loader.getProperty(query));
        final int offset = query.equals("ModifyReservation") ? -1 : 0;
        if(offset == 0) {
            stmt.setInt(1, reservation.getUserId());
        }

        Date date = Date.valueOf(reservation.getDate());
        stmt.setDate(2 + offset, date);
        stmt.setInt(3 + offset, reservation.getDuration());
        stmt.setInt(4 + offset, reservation.getCourtId());
        stmt.setFloat(5 + offset, reservation.getPrice());
        stmt.setFloat(6 + offset, reservation.getDiscount());
        stmt.setInt(7 + offset, reservation.getPackageId());
        stmt.setFloat(8 + offset, reservation.getSessionNumber());
        //Setting adults and children to 0 by default
        stmt.setFloat(9 + offset, 0);
        stmt.setFloat(10 + offset, 0);
        //Setting type to -1 to identify objects without set type
        stmt.setFloat(11 + offset, -1);

        return stmt;
    }

    /**
     * Creates a new adult reservation in the database
     * @param reservation Adult Reservation to be added to the database
     * @return true if it was successful, false otherwise
     */
    public boolean insertReservation(AdultReservationDTO reservation) {
        try {
            PreparedStatement stmt = _prepareBaseStatement(reservation, "InsertNewReservation");

            stmt.setInt(9, reservation.getAdultNumber());
            stmt.setString(11,  ReservationType.ADULT.name());

            stmt.executeUpdate();
            stmt.close();
        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();

            return false;
        }

        return true;
    }

    /**
     * Creates a new children reservation in the database
     * @param reservation children Reservation to be added to the database
     * @return true if it was successful, false otherwise
     */
    public boolean insertReservation(ChildrenReservationDTO reservation) {
        try {
            PreparedStatement stmt = _prepareBaseStatement(reservation, "InsertNewReservation");

            stmt.setInt(10, reservation.getChildrenNumber());
            stmt.setString(11,  ReservationType.CHILDREN.name());

            stmt.executeUpdate();
            stmt.close();
        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();

            return false;
        }

        return true;
    }

    /**
     * Creates a new family reservation in the database
     * @param reservation family Reservation to be added to the database
     * @return true if it was successful, false otherwise
     */
    public boolean insertReservation(FamilyReservationDTO reservation) {
        try {
            PreparedStatement stmt = _prepareBaseStatement(reservation, "InsertNewReservation");

            stmt.setInt(9, reservation.getAdultNumber());
            stmt.setInt(10, reservation.getChildrenNumber());
            stmt.setString(11, ReservationType.FAMILY.name());

            stmt.executeUpdate();
            stmt.close();
        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();

            return false;
        }

        return true;
    }

    /**
     * Gets all the reservations of a specific type
     * @param type Type of reservation
     * @return The list with all the reservations
     */
    public ArrayList<Reservation> getReservationsByType(ReservationType type) {
        ArrayList<Reservation> reservations = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ReservationTypeFilter"));

            stmt.setInt(1, type.ordinal());

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                reservations.add(_reservationFromDb(rs));
            }

            rs.close();
            stmt.close();
        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();

            return null;
        }

        return reservations;
    }

    /**
     * Deletes a reservation using a query
     * @param id Id of the court to delete
     * @param query Query to execute
     * @throws ReservationNotFoundException
     */
    private void _deleteReservationByQuery(Integer id, String query){
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty(query));
            stmt.setInt(1, id);

            int rs = stmt.executeUpdate();
            if(rs==0)
            {
            	throw new ReservationNotFoundException("Reservation not found. Unable to delete reservation.\n");
            }
            stmt.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
    }

    /**
     * Deletes a reservation using its ID
     * @param id ID of the reservation to delete
     */
    public void deleteReservationById(Integer id) {
        _deleteReservationByQuery(id, "ReservationDeleteById");
    }

    /**
     * Deletes a reservation using its package's ID
     * @param packageId Package ID of the reservation to delete
     */
    public void deleteReservationByPackageId(Integer packageId) {
        _deleteReservationByQuery(packageId, "ReservationDeleteByPackageId");
    }

    /**
     * Modifies an individual reservation
     * @param reservationId ID of the reservation to modify
     * @param reservation New information for the reservation
     * @param adult_number New number of adults
     * @param children_number New number of children
     */
    public void modifyReservationByUserId(Integer reservationId, Reservation reservation, int adult_number, int children_number) {
        try {
            PreparedStatement stmt = _prepareBaseStatement(reservation, "ModifyReservation");

            stmt.setFloat(8, adult_number);
            stmt.setFloat(9, children_number);
            stmt.setInt(10, reservationId);
            stmt.executeUpdate();

            stmt.close();
        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
    }
    
    /**
     * Gets the type of a reservation
     * @param id The ID of the reservation
     * @return The type of reservation
     */
    public ReservationType getReservationTypeById(Integer id)
    {
    	ReservationType type=null;
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ReservationTypeIdFilter"));
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if(!rs.next()) {
                return null;
            }

            type=ReservationType.valueOf(rs.getString("type"));

			if (stmt != null){ 
				stmt.close(); 
			}
            rs.close();

        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();
        
        }
        return type;
    }
    
    /**
     * Gets all the reservation
     * @return The ist with all the reservations
     */
    public ArrayList<Reservation> getReservations() {
        ArrayList<Reservation> reservations = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(loader.getProperty("ReservationsAllFilter"));
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                reservations.add(_reservationFromDb(rs));
            }

            rs.close();
            stmt.close();
        } catch (Exception e){
            System.err.println(e);
            e.printStackTrace();

            return null;
        }

        return reservations;
    }

}
