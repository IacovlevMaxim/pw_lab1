//package es.uco.pw.servlet;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet(name="checkage", urlPatterns="/checkage")
//public class RequestResponseServlet extends HttpServlet{
//
//	/** Serial ID */
//	private static final long serialVersionUID = 4852333670670107286L;
//	
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		String name = request.getParameter("name");
//		String age = request.getParameter("age");
//		
//		if(Integer.parseInt(age)>17) {
//			RequestDispatcher disp = request.getRequestDispatcher("helloworld");
//			disp.forward(request, response);
//		}
//		
//		else {
//			response.setContentType("text/html");
//			PrintWriter out = response.getWriter();
//			out.println("Sorry, " + name + " you are not 18 year-old!");
//			RequestDispatcher disp = request.getRequestDispatcher("index.html");
//			disp.include(request, response);
//		}
//	}
//}
